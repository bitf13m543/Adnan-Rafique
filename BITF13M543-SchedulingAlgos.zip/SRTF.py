arrival_time=[]
burst_time=[]
remaining_time=[]
total_wait=0
total_turnarround_time=0
total_process=int(input("Total Processes : "))
i=0
while i<total_process:
	print  ("For process :")
	print(i+1)
	burst_time.append(int(input("Burst time of process :")))
	arrival_time.append(int(input("Arrival time of process :")))
	remaining_time.append(burst_time[i])
	i+=1
print ("\n\nProcess\t|Turnaround Time| Waiting Time\n")
remaining_time.append(99999)
time=0
remain=0
j=i
while remain!=total_process:
    smallest=j
    i=0
    while i<total_process:
        if arrival_time[i]<=time and remaining_time[i]<remaining_time[smallest] and remaining_time[i]>0:
            smallest=i
        i+=1
    remaining_time[smallest]-=1
    if remaining_time[smallest]==0:
        remain+=1
        endTime=time+1
        print (smallest+1)
        print("\t","\t")
        print(endTime-arrival_time[smallest])
        print("\t","\t")
        print(endTime-burst_time[smallest]-arrival_time[smallest])
        total_wait+=endTime-burst_time[smallest]-arrival_time[smallest]
        total_turnarround_time+=endTime-arrival_time[smallest]
    time+=1
print ("\nAverage waiting time = ",total_wait*1.0/n)
print ("Average Turnaround time = ",total_turnarround_time*1.0/5)
