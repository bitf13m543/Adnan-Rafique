array = []
burst_time=[]
wait_time=[]
wait_total=0
total_process = int(input('Total processes: '))
arrival_time=(int(input('Process arrival time: ')))
for i in range(total_process):
    array.append([])
    array[i].append(int(input('Process number: ')))
    burst_time.append(int(input('Process burst time: ')))
j=1
for i in range(total_process):
    p=i
    for j in range(total_process):
        if burst_time[j]<burst_time[p]:
            p=j
        temp=burst_time[i]
        burst_time[i]=burst_time[p]
        burst_time[p]=temp
        temp=a[i]
        array[i]=a[p]
        array[p]=temp
wait.append(0)
j=0
for i in range(total_process):
    wait.append(0)
    for j in range(i):
        wait_time[i]+=burst_time[i]
    total_wait+=wait_time[i]
print ('ProcessNumber\tarrival_time\tburst_timeTime\tWaiting Time')
for i in range(total_process):
    print (a[i])
    print('\t\t')
    print(arrival_time)
    print('\t\t')
    print(burst_time[i])
    print('\t\t')
    print(wait_time[i])
print ('Total waiting time: ')
print(total_wait)
print ('Average waiting time: ')
print(total_wait/total_process)
 
 
