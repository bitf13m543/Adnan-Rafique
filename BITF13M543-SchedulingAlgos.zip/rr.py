remaining_burst_time=[]
t=0
a=[]
finish_time=[]
total_wait=[]
total_process=int (input('Total processes: '))
quantum_time=int (input('Quantum time: '))
for i in range(total_process):
	a.append([])
	a[i].append(input('Process name: '))
	a[i].append(int(input('Arrival time: ')))
	a[i].append(int(input('Burst time: ')))
	a[i].append(p[i][2]) #remaining burst time
	total+=a[i][2] #total burst time
	a[i].append(0) #finish time
a.sort(key=lambda a:a[1])
j=0
now=a[j][1]
while t>0:
	if a[j][3]<quantum_time and a[j][3]!=0 and a[j][1]<=now:
		t=t-a[j][3]
		now=now+a[j][3]
		a[j][4]=now
		a[j][3]=0
	elif a[j][3]>=quantum_time and a[j][1]<=now:
		a[j][3]=a[j][3]-quantum_time
		now=now+quantum_time
		t=t-quantum_time
		if a[j][3]==0:
			a[j][4]=now
	if (j+1)<total_process:
		j=j+1
	else:
		j=0
print ('Process\tArrival time\tBurst time\twaiting time')
for i in range(total_process):
	print (a[i][0])
	print(' \t\t')
	print(a[i][1])
	print(' \t\t')
	print(a[i][2])
	print(' \t\t')
	print(a[i][4]-a[i][1]-a[i][2])
