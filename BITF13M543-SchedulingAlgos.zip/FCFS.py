array = []
total_waiting = 0
total_process = int(input('Total processes: '))
for i in range(total_process):
    array.append([])
    array[i].append(input('Process name: '))
    array[i].append(int(input('Process arrival time: ')))
    total_waiting += array[i][1]
    array[i].append(int(input('Process burst time: ')))
array.sort(key = lambda array:array[1])
print ('Process Name\tArrival Time\tBurst Time')
for i in range(total_process):
    print (array[i][0])
    print ('\t\t')
    print (array[i][1])
    print('\t\t')
    print(array[i][2])
print ('Total waiting time: ')
print(total_waiting)
print ('Average waiting time: ')
print(total_waiting/total_process)
 
 
